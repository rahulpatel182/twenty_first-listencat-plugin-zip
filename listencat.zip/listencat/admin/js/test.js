function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.innerHTML === "This post does not have audio") {
    x.innerHTML = "This post has audio enabled";
  } else {
    x.innerHTML = "This post does not have audio";
  }
}


function custom_checkbox(post_id){ 
    var postid = {check_data:post_id};
    $.ajax({
            type: "POST",
            url: "insert_postmeta.php",
            data: postid,
            success: function(response) {
             alert(response);
            }
            });
}


// function check_option_value(){ 
//     var postid = {check_data:post_id};
//     $.ajax({
//             type: "POST",
//             url: "insert_postmeta.php",
//             data: postid,
//             success: function(response) {
//              alert(response);
//             }
//             });
// }


//  $(document).ready(function() { 
//  	$('#submit').click(function(){ 
//     var postid = {check_data:post_id};
//     // console.log(postid);
//     $.ajax({
//             type: "POST",
//             url: "admin.php",
//             data: postid,
//             success: function(response) {
//              alert(response);
//             }
//             });
// });
// });


    



