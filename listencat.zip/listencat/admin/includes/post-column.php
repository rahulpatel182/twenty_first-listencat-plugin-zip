<?php

class Post_Column {

  function __construct() {

    add_filter('manage_posts_columns', array( $this,'custom_posts_column_heading'));
    add_action( 'manage_posts_custom_column', array( $this,'custom_posts_column_content'), 10, 2 );

    add_filter( 'bulk_actions-edit-post', array( $this,'register_my_bulk_actions' ));
    add_filter( 'handle_bulk_actions-edit-post',array( $this, 'my_bulk_action_handler'), 10, 3 );
        // add_action( 'admin_notices', array( $this,'my_bulk_action_admin_notice' ));
 
  }
  
  public function custom_posts_column_heading($defaults) { 

    $defaults['listen']  = 'Listen';
    $defaults['play_minutes']  = 'Play minutes';
    return $defaults;

    } // end custom_posts_column_heading()


  public function custom_posts_column_content( $column_name, $post_id ) {

    if($column_name == 'listen') {   $check = get_post_meta($post_id,'Status',true); ?>  

      <label class="switch">
      <input type="checkbox" <?php if(!empty($check)){ echo($check=='active')?"checked":"";} ?>  onclick="custom_checkbox(<?php echo $post_id ?>);"  id="custom_check" name="listen_button" >
      <span  class="slider round"></span>
      </label> 

      <?php    }
  
   } // end custom_posts_column_content()

    public function register_my_bulk_actions($bulk_actions) {

        $bulk_actions['add_audio'] = __( 'Add audio', 'add_audio');
        $bulk_actions['remove_audio'] = __( 'Remove audio', 'remove_audio');
        return $bulk_actions;
    }
 
    public function my_bulk_action_handler( $redirect_to, $doaction, $post_ids ) { 

        if ( $doaction != ('add_audio' || 'remove_audio')) {            
            return $redirect_to; 
        }

        if($doaction == 'add_audio'){ $status='active'; }else{ $status='deactive'; }    
        foreach ( $post_ids as $post_id ) {
            update_post_meta($post_id, 'Status', $status);
        }
        $redirect_to = add_query_arg( 'insert_postmeta', count( $post_ids ), $redirect_to );
        return $redirect_to;         
    }

      // public function my_bulk_action_admin_notice() {
    //     if ( ! empty( $_REQUEST['insert_postmeta'] ) ) {
    //         $post_count = intval( $_REQUEST['insert_postmeta'] );
    //         // print_r( $post_count);
   //         printf( '<div id="message" class="updated notice is-dismissible">' .
    //          _n( 'Post %s inserted.',
    //             'POSTS %s inserted.',
    //             $post_count,
    //             'add_audio'
    //             'remove_audio'
    //           ) . '</div>', $post_count );
    //       }
    //     }
           

  } // End  Post_Column

  $post_column = new Post_Column();




  
