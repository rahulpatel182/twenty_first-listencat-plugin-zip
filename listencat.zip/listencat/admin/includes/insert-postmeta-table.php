<?php  
      if(isset($_POST['check_data'])){

      	$check_data = $_POST['check_data'];

      	// print_r($check_data);die();

       $check = get_post_meta($check_data,'Status',true);

       if($check=='active'){

       	$Status = 'deactive';

   	  } 
   	  else
      {

	     $Status = 'active'; 
	  }
        update_post_meta($check_data, 'Status', $Status);

      }
?>