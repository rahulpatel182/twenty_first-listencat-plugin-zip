<?php

class Meta_Box {

   function __construct() {

      add_action( 'add_meta_boxes', array( $this, 'add_metabox'  ));
        add_action( 'save_post',      array( $this, 'save_metabox' ), 10, 2 );
   
  }
  
  public function add_metabox() {
        add_meta_box(
            'my-meta-box',
            __( 'Listencat', 'textdomain' ),
            array( $this, 'render_metabox' ),
            'post',
            'side',
            'default'
        );
    }

    public function render_metabox( $post ) {
        // Add nonce for security and authentication.
        wp_nonce_field( 'custom_nonce_action', 'custom_nonce' );
         ?>
        <label class="switch">
        <input type="checkbox" onclick="myFunction()">
        <span class="slider round"></span>

        </label>
         <div id="myDIV">This post does not have audio</div>
        <?php
    }

    public function save_metabox( $post_id, $post ) {
        // Add nonce for security and authentication.
        $nonce_name   = isset( $_POST['custom_nonce'] ) ? $_POST['custom_nonce'] : '';
        $nonce_action = 'custom_nonce_action';
        // Check if nonce is valid.
        if ( ! wp_verify_nonce( $nonce_name, $nonce_action ) ) {
            return;
        }
         // Check if user has permissions to save data.
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        // Check if not an autosave.
        if ( wp_is_post_autosave( $post_id ) ) {
            return;
        }
         // Check if not a revision.
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }
    }// end save_metabox()

  } // End  Post_Column

  $meta_box = new Meta_Box();




  
