<?php
require_once $plugin_path . 'includes/post-column.php';
require_once $plugin_path . 'includes/insert-postmeta-table.php';
require_once $plugin_path . 'includes/meta-box.php';


class Listencat {
	
    function __construct() {

		add_action('admin_menu', array( $this,'blog_plugin_setup_menu'));
                 
	}

	public function blog_plugin_setup_menu(){

	    add_menu_page( 'Listencat', 'Listencat', 'manage_options', 'listencat', array($this,'listencat_plugin'),' dashicons-admin-plugins');

	  	add_submenu_page( 'listencat', 'Setup', 'Setup','manage_options', 'setup_tab', array($this,'setup_tab_detail'));
	}
 
 	public function listencat_plugin($current = 'first') { ?>

    	<div class="wrap">
      	<h1>Listencat.com Plugin</h1>

        <?php $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'home'; ?> 

        <h2 class="nav-tab-wrapper">

        <a href="?page=listencat" name="home" class="nav-tab <?php echo $active_tab == 'home' ? 'nav-tab-active' : ''; ?>">Home</a>
            
        <a href="?page=setup_tab" class="nav-tab">Setup</a>

        </h2>     
        </div>

        <h1>Home</h1>
		<form method="POST" action="" name="formdata">
        <input type="text"  name="website_name"  id="website_name" placeholder='Website Name'        
        <?php if(empty(['website_name'])){
        	 echo "";
       	}
       	elseif (isset($_POST['website_name'])) {
     		// echo $_POST['website_name'];
        echo "value='".$_POST['website_name']."'";	
       	// echo get_option('website_name');       		
       	}
       	else
        {
        	echo "value='".get_option('website_name')."'";
         // echo get_option('website_name');
        }
        ?> >

        
		<?php submit_button('Save'); ?>
		<br><br>
		<iframe src="<?php if(empty(['website_name'])){
        	echo'';
       	}
       	elseif (isset($_POST['website_name'])) {
      		echo $_POST['website_name'];	
       	// echo get_option('website_name');       		
       	}
       	else
        {
         echo get_option('website_name');
        } ?>"  height="400" width="100%" name="website_name"  ></iframe>
		</form>
	  	<?php 
		require_once( trailingslashit( ABSPATH ) .'wp-load.php' );
	    if( isset($_POST['submit']) ) {	
        update_option('website_name',$_POST['website_name']);          
    	}
    	    			
	} // END third_party_blog_init


	public function setup_tab_detail(){  ?> 
    
        <h1>Listencat.com plugin settings</h1>
        <div class="wrap">
     
        <?php $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'setup'; ?> 

        <h2 class="nav-tab-wrapper">

        <a href="?page=listencat" name="home" class="nav-tab">Home</a>
            
        <a href="?page=setup_tab" class="nav-tab <?php echo $active_tab == 'setup' ? 'nav-tab-active' : ''; ?>">Setup</a>

        </h2>     
        </div>
        <div class="main_div">
               

        <?php 

          if( isset($_POST['submit']) ) { 
          $token  = $_POST['token_number'];
          update_option('token_number',$token);
          }; 

          // $checking =  get_option('token_number');

        ?>

        <p>Connect with your Listencat.com account to enable the plugin</p>
		    <form method="POST" action="">
	     	<label>Enter API key: </label>
		    <input type="text" name="token_number" class="token_number" placeholder="Enter API key here"  autocomplete="off" <?php if(empty(['token_number'])){
           echo "";
        } elseif (isset($_POST['submit']) ) { $token  = $_POST['token_number']; echo "value='".$_POST['token_number']."'"; } else {  echo "value='".get_option('token_number')."'"; } ?>><br>

      <p class="p_text">You can find the API key in the settings sections of<br>your Listencat.com account</p>

		  <?php submit_button('Connect your account'); ?>

        <p class="p_text2">Don't have an account?<a href="#">Sign up for free</a></p>
		    </form>
        </div>

          <?php
         
          if( isset($_POST['save_settings'])) {
          $check1 = $_POST['column1'];
          $check2 =$_POST['column2'];
          $check3= $_POST['column3'];
   
          update_option('checkbox1',$check1);
          update_option('checkbox2',$check2);
          update_option('checkbox3',$check3);
          }

          $update_checkbox1 =  get_option('checkbox1');
          if(!empty($update_checkbox1)){ ($update_checkbox1 =='on')? $checked1 ="checked":$checked1 ='';}

          $update_checkbox2 =  get_option('checkbox2');
          if(!empty($update_checkbox2)){ ($update_checkbox2 =='on')? $checked2 ="checked":$checked2 ='';}

          $update_checkbox3 =  get_option('checkbox3');
          if(!empty($update_checkbox3)){ ($update_checkbox3 =='on')? $checked3 ="checked":$checked3 ='';}

          $form ="<form method='POST' action=''>
          <div class='condition_section'>
          <input type='checkbox' name='column1'  ".$checked1.">add audio to new artical automatically<br>statistics to display in Pages list view:<br><br> 
          <input type='checkbox' name='column2'".$checked2." >Play time column <br><br>
          <input type='checkbox' name='column3'".$checked3." >Play count column<br><br>
          <span>You can view live statistics and adjust other settings in your Listencat.com account<br>Need help?Click<a href='#'>here</a> for support</span><br><br>

          <input type='submit' name='save_settings' id='save_settings' class='button button-primary' value='Save settings'/>
          </form>";

          $checking =  get_option('token_number');
          $token  = $_POST['token_number'];

          error_reporting(E_ALL);  
          ini_set("display_errors", 1); 
          // print_r($checking);
          $curl = curl_init();
           // print_r($curl);
          curl_setopt($curl, CURLOPT_URL,'https://listencat.com/api/v1/post?id=1');
          // print_r($url);die();
          // curl_setopt($curl, CURLOPT_HEADER, TRUE);        
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
          // print_r($return_transfer);die();
          curl_setopt($curl, CURLOPT_HTTPHEADER, ['content-type: application/json']);

          $headers = array('Authorization: Bearer '.$checking,
                      
                    
                  );
                  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
         
               $response = curl_exec($curl); 
            // $response1 = json_decode($response);

          $error = curl_error($curl);
       
          // $api='jwI74CeYhJsDUrgP8VJ8L9njhtxVDQfhS8twIo78MCnGLFMhrqy5LA0IxzFg';
        
          
          curl_close($curl);
             $data = json_decode($response);
          if(empty($data)) {
                  echo "wrong api key" .$error;

                  }
                  else{
                    echo $form;
                  }
      

	} // End setup_tab_detail
   
  
} // END CLASS

$listencat = new Listencat();	




