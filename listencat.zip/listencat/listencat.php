
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>             

<?php
/**
 * @package Blog
 */
/*
Plugin Name: Listencat
Plugin URI: https://blog.com/
Description: Plugin description goes here..
Version: 1.0.0
Author: Automatic
Author URI: https://automattic.com/wordpress-plugins/
License: GPLv2 or later
Text Domain: blog
*/

require_once $plugin_path . 'admin/admin.php';
// require_once $plugin_path . 'admin/custom_posts_column.php';
// require_once $plugin_path . 'admin/insert_postmeta.php';



// require_once $plugin_path . 'admin/js/test.js';



function stylesheet_enqueue()
{
    // Register the style like this for a plugin:
    wp_register_style( 'custom-style', plugins_url( 'admin/css/style.css', __FILE__ ), array(), '1.0.0', 'all' );
    
    // For either a plugin or a theme, you can then enqueue the style:
    wp_enqueue_style( 'custom-style' );
}
add_action( 'init', 'stylesheet_enqueue' );


function custom_script_enqueue()
{
    // Register the script like this for a plugin:
    wp_register_script( 'custom-script', plugins_url( 'admin/js/test.js', __FILE__ ), array( 'jquery' ), '1.0.0', true );
    // For either a plugin or a theme, you can then enqueue the script:
    wp_enqueue_script( 'custom-script' );

    // wp_enqueue_script( 'ajax-script',
    //     plugins_url( '/js/myjsfile.js', __FILE__ ),
    //     array( 'jquery' )
}
add_action( 'init', 'custom_script_enqueue' );










